# Macro para importar la wiki de Sword World 2.5

El importador del sistema sabe convertir páginas individuales, pero no contiene un índice global de la wiki. Esta macro comienza en las páginas índice que indiques, sigue sus enlaces internos y crea/actualiza items del mundo para razas, clases, feats y páginas de habilidades de clase. Usa el importador ya cargado por el sistema (`game.sw25.importer`) para descargar y analizar las páginas.

1. En Foundry, crea una macro de tipo **Script**.
2. Copia el código de abajo.
3. Edita `START_URLS` con páginas índice de la wiki (por ejemplo, las páginas que enlazan la lista de razas, clases, feats y conjuros).
4. Ejecútala como GM. Se puede volver a ejecutar: actualiza el item cuyo `sourceUrl` coincide.

```js
// Sword World 2.5: rastrea enlaces desde los índices indicados y guarda
// items como documentos del mundo. Ejecutar como GM.
ui.notifications.info("Macro de importación SW25 iniciada.");
console.info("SW25 wiki import: macro iniciada");
try {
const I = game.sw25?.importer;
if (!I) throw new Error("No se encuentra game.sw25.importer. Comprueba que Sword World 2.5 esté activo.");
if (!game.user.isGM) throw new Error("Ejecuta esta macro como GM.");
// Este módulo es parte del sistema y solo se carga cuando la macro lo necesita.
const equipmentParser = await import("/systems/sword-world-25/module/importer/equipment-parser.mjs");

// Sustituye/añade índices conocidos de la wiki. La macro solo descubre páginas
// enlazadas desde estos puntos de partida; no hay un índice completo público
// que el importador pueda recorrer automáticamente.
const START_URLS = [
  "https://sw25.wikidot.com/",
  "https://sw25.wikidot.com/races",
  "https://sw25.wikidot.com/classes",
  "https://sw25.wikidot.com/spellsongs",
  "https://sw25.wikidot.com/finales",
  "https://sw25.wikidot.com/evocations",
  "https://sw25.wikidot.com/techniques",
  "https://sw25.wikidot.com/aspects",
  "https://sw25.wikidot.com/infusions",
  "https://sw25.wikidot.com/stunts",
  "https://sw25.wikidot.com/stratagems",
  "https://sw25.wikidot.com/maneuvers",
  "https://sw25.wikidot.com/weavings",
  "https://sw25.wikidot.com/feats",
  "https://sw25.wikidot.com/spells",
  "https://sw25.wikidot.com/items",
  "https://sw25.wikidot.com/items:axes",
  "https://sw25.wikidot.com/items:bows",
  "https://sw25.wikidot.com/items:crossbows",
  "https://sw25.wikidot.com/items:flails",
  "https://sw25.wikidot.com/items:guns",
  "https://sw25.wikidot.com/items:innate-weapons",
  "https://sw25.wikidot.com/items:maces",
  "https://sw25.wikidot.com/items:spears",
  "https://sw25.wikidot.com/items:staves",
  "https://sw25.wikidot.com/items:swords",
  "https://sw25.wikidot.com/items:thrown-weapons",
  "https://sw25.wikidot.com/items:warhammers",
  "https://sw25.wikidot.com/items:wrestling",
];
const MAX_PAGES = 1200;
const DELAY_MS = 350;
const PAGE_PREFIXES = /^(race|class|feat|spell|spells|evocation|spellsong|finale|essence-weaving|weaving|technique|aspect|infusion|stunt|stratagem|maneuver|items):/i;
const FEATURE_PREFIX = /^(spell|evocation|spellsong|finale|essence-weaving|weaving|technique|aspect|infusion|stunt|stratagem|maneuver):/i;
const WEAPON_CATEGORIES = new Set(["axes", "swords", "spears", "maces", "staves", "flails", "warhammers", "bows", "crossbows", "guns", "thrown", "thrown-weapons", "wrestling", "innate-weapons"]);
const EQUIPMENT_OPTIONS = {
  "items:general-equipment": {},
  "items:adventure-tools": { defaultCategory:"Adventure Tools" },
  "items:adventure-tools-consumable": { defaultCategory:"Adventure Tools (Consumable)", consumable:true },
  "items:ammunition": { defaultCategory:"Ammunition", consumable:true },
  "items:herbs-potions-chemicals": { consumable:true },
  "items:accessories": {},
  "items:class-specific": { classSpecific:true },
  "items:golem-enhancing": { defaultCategory:"Golem-Enhancing Items" },
  "items:living-expenses": { defaultCategory:"Living Expenses and Lodging" },
  "items:special-musical-instruments": { defaultCategory:"Special Musical Instruments" },
  "items:weapon-armor-enhancements": { defaultCategory:"Weapon and Armor Enhancements" }
};
const folderAliases = {
  "Races":["Razas"], "Classes":["Clases"], "Spells":["Conjuros"],
  "Features":["Habilidades"], "Weapons":["Armas"], "Armor & Shields":["Armaduras y escudos"],
  "Equipment":["Equipo"], "Mounts":["Monturas"], "Other":["Otros"],
  "Uncategorized":["Sin categoría", "Sin categorÃ­a"]
};
const folderCache = new Map();
const ensureFolder = async (name, parentId = null) => {
  const key = `${parentId || "root"}|${name}`;
  if (folderCache.has(key)) return folderCache.get(key);
  let folder = game.folders.find(f => f.type === "Item" && f.name === name && (f.folder?.id || null) === parentId);
  if (!folder) {
    const aliases = folderAliases[name] || [];
    folder = game.folders.find(f => f.type === "Item" && aliases.includes(f.name) && (f.folder?.id || null) === parentId);
    if (folder) await folder.update({ name });
  }
  if (!folder) folder = await Folder.create({ name, type:"Item", ...(parentId ? { folder:parentId } : {}) });
  folderCache.set(key, folder.id);
  return folder.id;
};
const folderFor = async (data, page, parsed) => {
  const type = data.type;
  let root, category = "", level = 0, flat = false;
  if (type === "race") { root = "Races"; category = page.context?.category || raceCategoryFromSlug(page.slug) || "Uncategorized"; }
  else if (type === "class") {
    root = "Classes";
    const kind = String(parsed?.classType || data.system?.classType || "").toLowerCase();
    category = kind.includes("warrior") ? "Warrior" : kind.includes("wizard") ? "Wizard" : kind ? "Other" : "Uncategorized";
  } else if (type === "feat") {
    root = "Feats";
    category = /^Selectively Acquired (?:Active|Passive)$/.test(page.context?.category || "")
      ? page.context.category
      : `Level ${featMinimumLevel(parsed?.prerequisite || data.system?.prerequisite)}`;
  } else if (type === "spell") {
    root = "Spells";
    category = page.context?.category || spellCategory(parsed?.requirement || data.system?.requirement, page.slug);
    level = Number(data.system?.level) || 1;
  } else if (type === "ability") { root = "Features"; category = String(data.system?.className || "Other"); }
  else if (type === "weapon") { root = "Weapons"; category = displayCategory(data.system?.category || page.slug.slice(6)); }
  else if (type === "armour") { root = "Armor & Shields"; category = page.slug.toLowerCase().endsWith("shields") ? "Shields" : page.slug.toLowerCase().endsWith("metal-armor") ? "Metal Armor" : "Nonmetallic Armor"; }
  else if (type === "equipment") {
    if (page.slug.toLowerCase() === "mounts") { root = "Mounts"; flat = true; }
    else { root = "Equipment"; category = displayCategory(equipmentCategory(page.slug)); }
  } else { root = "Other"; }
  const rootId = await ensureFolder(root);
  if (flat) return rootId;
  const categoryId = category ? await ensureFolder(category, rootId) : rootId;
  if (type === "ability") {
    const featureFolders = { evocation:"Evocations", spellsong:"Spellsongs", finale:"Finales", weaving:"Essence Weavings", technique:"Techniques", aspect:"Aspects", infusion:"Infusions", stunt:"Stunts", stratagem:"Stratagems", maneuver:"Maneuvers" };
    return ensureFolder(featureFolders[String(data.system?.featureType || "").toLowerCase()] || displayCategory(data.system?.featureType || "Class Feature"), categoryId);
  }
  if (level > 0) return ensureFolder(`Level ${level}`, categoryId);
  return categoryId;
};
const displayCategory = value => String(value || "Uncategorized").replace(/[-_]+/g, " ").replace(/\b\w/g, c => c.toUpperCase());
const equipmentCategory = slug => ({
  "items:accessories":"Accessories", "items:adventure-tools":"Adventure Tools",
  "items:adventure-tools-consumable":"Adventure Tools (Consumable)", "items:ammunition":"Ammunition",
  "items:class-specific":"Class-Specific Items", "items:general-equipment":"General Equipment and Supplies",
  "items:golem-enhancing":"Golem-Enhancing Items", "items:herbs-potions-chemicals":"Herbs, Potions, Chemicals, Repair Tools",
  "items:living-expenses":"Living Expenses and Lodging", "items:special-musical-instruments":"Special Musical Instruments",
  "items:weapon-armor-enhancements":"Weapon and Armor Enhancements"
}[slug.toLowerCase()] || "Equipment");
const raceCategoryFromSlug = slug => {
  const key = String(slug || "").split(":").slice(1).join(":").toLowerCase().replace(/_/g, "-");
  const humanoid = new Set(["dwarf", "elf", "grassrunner", "human", "leprechaun", "lildraken", "lykant", "meria", "nightmare", "runefolk", "tabbit", "tiens"]);
  const rare = new Set(["abyssborn", "alv", "dark-dwarf", "fey", "fluorite", "magitech-angel", "miakis", "newman", "sentian", "shadow", "soleil", "spriggan", "valkyrie", "weakling"]);
  const barbarous = new Set(["arbor", "baba-yaga", "basilisk", "broken-drake", "centaur", "dark-troll", "dawn", "dhampir", "diablo", "drake", "kobold", "lamia", "lizardman", "lycanthrope", "scissorscorpion", "vulcan"]);
  return humanoid.has(key) ? "Humanoid" : rare.has(key) ? "Rare Humanoid" : barbarous.has(key) ? "Barbarous" : "";
};
const featMinimumLevel = value => {
  const text = String(value || "");
  const matches = [...text.matchAll(/(?:adv(?:enturer)?\.?\s*)?(?:class\s*)?(?:level|lvl)\s*(\d+)/gi)].map(m => Number(m[1]));
  return matches.length ? Math.min(...matches) : 1;
};
const spellCategory = (requirement, slug) => {
  const path = String(slug || "").toLowerCase();
  if (/by-divinity|divine-[a-z]/.test(path)) return "Divine by Divinity";
  if (/spell:/.test(path) && /divine/i.test(String(requirement))) return "Divine Common";
  const school = String(requirement || "").split(/[,:]/)[0].trim();
  return school || "Other";
};
const spellCategoryFromSlug = slug => {
  const key = String(slug || "").toLowerCase().replace(/^spells:/, "");
  if (key === "divine") return "Divine Common";
  if (key.includes("divine")) return "Divine by Divinity";
  const labels = { abyssal:"Abyssal Magic", "deep":"Deep Magic", fairy:"Fairy Magic", magitech:"Magitech", nature:"Nature", spiritualism:"Spiritualism", summoning:"Summoning Arts", truespeech:"Truespeech" };
  return Object.entries(labels).find(([prefix]) => key.startsWith(prefix))?.[1] || "Other";
};
const sectionContexts = (fetched, pageSlug) => {
  const result = new Map();
  if (fetched.kind !== "html") {
    let section = "";
    let selectiveFeatCategory = "";
    for (const line of String(fetched.text || "").split(/\r?\n/)) {
      const heading = line.match(/^#{1,6}\s+(.+?)\s*#*$/);
      if (heading) {
        section = heading[1].replace(/[*_`]/g, "").trim();
        if (pageSlug === "feats" && (line.match(/^#+/)?.[0].length || 6) <= 4) {
          const selective = section.match(/Selectively Acquired (Active|Passive)/i);
          selectiveFeatCategory = selective ? `Selectively Acquired ${selective[1][0].toUpperCase()}${selective[1].slice(1).toLowerCase()}` : "";
        }
        continue;
      }
      let category = "";
      if (pageSlug === "races") category = /^Humanoid Races$/i.test(section) ? "Humanoid" : /^Rare Humanoid Races$/i.test(section) ? "Rare Humanoid" : /^Barbarous PC Races$/i.test(section) ? "Barbarous" : "";
      else if (pageSlug === "feats" && selectiveFeatCategory) category = selectiveFeatCategory;
      if (!category) continue;
      for (const match of line.matchAll(/\[[^\]]+\]\((https?:\/\/[^)]+|\/[^)]+)\)/g)) {
        try { result.set(canonical(new URL(match[1], "https://sw25.wikidot.com/").href), { category }); } catch (_) {}
      }
    }
    return result;
  }
  // Lee los intervalos del HTML fuente. Wikidot puede envolver cada enlace
  // en varias capas DOM, así que asociamos los anchors al encabezado anterior.
  const source = String(fetched.text || "");
  const headings = [...source.matchAll(/<h([1-6])\b[^>]*>([\s\S]*?)<\/h\1\s*>/gi)];
  const categoryForHeading = title => {
    if (pageSlug === "races") {
      if (/Rare Humanoid Races/i.test(title)) return "Rare Humanoid";
      if (/Humanoid Races/i.test(title)) return "Humanoid";
      if (/Barbarous PC Races/i.test(title)) return "Barbarous";
    }
    if (pageSlug === "feats") {
      const match = title.match(/Selectively Acquired (Active|Passive)/i);
      if (match) return `Selectively Acquired ${match[1][0].toUpperCase()}${match[1].slice(1).toLowerCase()}`;
    }
    return "";
  };
  for (let i = 0; i < headings.length; i++) {
    const title = headings[i][2].replace(/<[^>]*>/g, " ").replace(/&nbsp;|&#160;/gi, " ").replace(/\s+/g, " ").trim();
    const category = categoryForHeading(title);
    if (!category) continue;
    const level = Number(headings[i][1]);
    const start = headings[i].index + headings[i][0].length;
    const next = headings.slice(i + 1).find(h => Number(h[1]) <= level);
    const end = next ? next.index : source.length;
    const block = source.slice(start, end);
    for (const linkMatch of block.matchAll(/href\s*=\s*["']([^"']+)["']/gi)) {
      try {
        const link = canonical(new URL(linkMatch[1], "https://sw25.wikidot.com/").href);
        const path = decodeURIComponent(new URL(link).pathname.replace(/^\//, ""));
        if (/^(?:race|feat):/i.test(path)) result.set(link, { category });
      } catch (_) {}
    }
  }
  if (result.size) return result;
  const doc = new DOMParser().parseFromString(String(fetched.text || ""), "text/html");
  const content = doc.querySelector("#page-content, .page-content, #pageContent") || doc.body;
  let section = "";
  let selectiveFeatCategory = "";
  for (const node of content.querySelectorAll("h1,h2,h3,h4,h5,h6,a")) {
    if (/^H[1-6]$/.test(node.tagName)) {
      section = String(node.textContent || "").trim();
      if (pageSlug === "feats" && Number(node.tagName.slice(1)) <= 4) {
        const selective = section.match(/Selectively Acquired (Active|Passive)/i);
        selectiveFeatCategory = selective ? `Selectively Acquired ${selective[1][0].toUpperCase()}${selective[1].slice(1).toLowerCase()}` : "";
      }
      continue;
    }
    let category = "";
    if (pageSlug === "races") {
      if (/^Humanoid Races$/i.test(section)) category = "Humanoid";
      else if (/^Rare Humanoid Races$/i.test(section)) category = "Rare Humanoid";
      else if (/^Barbarous PC Races$/i.test(section)) category = "Barbarous";
    } else if (pageSlug === "feats") {
      if (selectiveFeatCategory) category = selectiveFeatCategory;
    }
    if (category && node.href) {
      try { result.set(canonical(new URL(node.href, location.href).href), { category }); } catch (_) {}
    }
  }
  return result;
};
const pageTitle = (fetched, url) => {
  let title = "";
  if (fetched.kind === "html") {
    const doc = new DOMParser().parseFromString(String(fetched.text || ""), "text/html");
    title = String(doc.title || "");
  } else {
    title = String(fetched.text || "").match(/^Title:\s*(.+)$/mi)?.[1] || "";
    if (!title) title = String(fetched.text || "").match(/^#{1,3}\s+(.+)$/m)?.[1] || "";
  }
  title = title.replace(/\s+-\s+Sword World(?: 2\.5)? Reference Wiki.*$/i, "").trim();
  if (/^Sword World 2\.5 Reference Wiki$/i.test(title)) title = "";
  return title || decodeURIComponent(new URL(url).pathname.split(":").pop() || "Imported Item").replace(/[-_]+/g, " ").replace(/\b\w/g, c => c.toUpperCase());
};
const parseMountRows = (fetched, url) => {
  const rows = [];
  if (fetched.kind === "html") {
    const doc = new DOMParser().parseFromString(String(fetched.text || ""), "text/html");
    const content = doc.querySelector("#page-content, .page-content, #pageContent") || doc.body;
    for (const table of content.querySelectorAll("table")) {
      const tableRows = [...table.querySelectorAll("tr")].map(tr => [...tr.querySelectorAll("th,td")].map(cell => String(cell.textContent || "").replace(/\s+/g, " ").trim()));
      const headerIndex = tableRows.findIndex(r => r.some(c => /^name$/i.test(c)) && r.some(c => /purchase price/i.test(c)));
      if (headerIndex < 0) continue;
      const headers = tableRows[headerIndex].map(h => h.toLowerCase());
      const col = pattern => headers.findIndex(h => pattern.test(h));
      const nameCol = col(/^name$/i), levelCol = col(/appropriate level/i), priceCol = col(/purchase price/i), rentalCol = col(/rental price/i), medicineCol = col(/smo?s?rp|medicine/i), notesCol = col(/^notes?$/i);
      for (const cells of tableRows.slice(headerIndex + 1)) {
        const name = cells[nameCol] || "";
        if (!name || /^name$/i.test(name)) continue;
        const purchase = cells[priceCol] || "";
        const notes = [levelCol >= 0 && cells[levelCol] ? `Appropriate Level: ${cells[levelCol]}` : "", rentalCol >= 0 && cells[rentalCol] ? `Rental Price: ${cells[rentalCol]}` : "", medicineCol >= 0 && cells[medicineCol] ? `SMoSRP: ${cells[medicineCol]}` : "", notesCol >= 0 ? cells[notesCol] : ""].filter(Boolean).join("; ");
        rows.push({ name, category:"Mounts", stance:"-", consumable:false, price:Number(purchase.replace(/,/g, "").match(/\d+/)?.[0] || 0), priceText:purchase, notes, sourceUrl:url });
      }
    }
  }
  return rows;
};
const featureInput = (fetched, url) => {
  if (fetched.kind !== "html") return String(fetched.text || "").split(/\r?\n/)
    .map(line => line.includes("|") ? line.split("|").map(cell => cell.trim()).filter(Boolean).join(" ") : line).join("\n");
  const doc = new DOMParser().parseFromString(String(fetched.text || ""), "text/html");
  const title = String(doc.title || "").replace(/\s+-\s+Sword World 2\.5 Reference Wiki.*$/i, "").trim();
  const content = doc.querySelector("#page-content, .page-content, #pageContent");
  if (!content) return fetched.text;
  content.querySelectorAll("script, style, noscript, .page-options-bottom, .page-info, .page-tags, .footer, #footer, #side-bar, #top-bar").forEach(node => node.remove());
  // Conserva el HTML: el parser del sistema convierte cierres de párrafo,
  // encabezados y filas en saltos de línea antes de leer los campos.
  // Aplana las tablas por filas para que el parser reconozca sus power tables.
  content.querySelectorAll("table").forEach(table => {
    const rows = [...table.querySelectorAll("tr")].map(row => [...row.querySelectorAll("th,td")]
      .map(cell => String(cell.textContent || "").replace(/\s+/g, " ").trim()).join(" ").trim()).filter(Boolean);
    if (rows.length) table.replaceWith(doc.createTextNode(`\n${rows.join("\n")}\n`));
  });
  const body = String(content.innerHTML || "").trim();
  const fallbackName = decodeURIComponent(new URL(url).pathname.split(":").pop() || "").replace(/[-_]+/g, " ");
  return `Title: ${title || fallbackName}\n\n${body}`;
};
// El proxy CORS suele devolver la página completa de Wikidot. Los parsers
// de armas/equipo esperan el texto limpio que ofrece Reader: encabezados
// Markdown y cada fila de tabla en una línea con celdas separadas por espacios.
const featureClassName = featureType => ({
  evocation:"Alchemist", spellsong:"Bard", finale:"Bard", weaving:"Dark Hunter",
  technique:"Enhancer", aspect:"Geomancer", infusion:"Heritor", stunt:"Rider",
  stratagem:"Tactician", maneuver:"Tactician"
}[String(featureType || "").toLowerCase()] || "Other");
const normalizeReaderTables = input => String(input || "").split(/\r?\n/)
  .map(line => line.includes("|") ? line.split("|").map(cell => cell.trim()).filter(Boolean).join(" ") : line).join("\n");
const readablePowerTable = parsed => {
  const description = String(parsed?.description || "");
  if (!parsed?.hasPowerTable) return description;
  const lines = description.split(/\n+/);
  const kept = [];
  let skipValues = false;
  for (const line of lines) {
    if (/^Power\s+\S+(?:\s+\S+){9}\s+Crit(?:ical)?$/i.test(line.trim())) { skipValues = true; continue; }
    if (skipValues && /^\s*\d+(?:\s+-?\d+){9}\s+(?:[+-]?\d+|[③④⑤⑥⑦⑧⑨⑩⑪⑫]|none)\s*$/i.test(line.trim())) { skipValues = false; continue; }
    skipValues = false;
    kept.push(line);
  }
  const values = Array.from({ length:10 }, (_, index) => `${index + 3}: ${parsed.powerTable?.[String(index + 3)] ?? 0}`);
  const table = `Power Table (Power ${parsed.power || 0}, Critical ${parsed.critical || "—"})\n${values.join("  |  ")}`;
  return [kept.join("\n\n").trim(), table].filter(Boolean).join("\n\n");
};
const parserInput = fetched => {
  if (fetched.kind !== "html") return normalizeReaderTables(fetched.text);
  const doc = new DOMParser().parseFromString(String(fetched.text || ""), "text/html");
  const content = doc.querySelector("#page-content, .page-content, #pageContent") || doc.body;
  content.querySelectorAll("script,style,noscript,nav,header,footer,#side-bar,#top-bar,.page-options-bottom,.page-info,.page-tags").forEach(node => node.remove());
  // Procesar filas primero para que el parser reciba cada objeto completo.
  content.querySelectorAll("tr").forEach(row => {
    const cells = [...row.querySelectorAll("th,td")].map(cell => String(cell.textContent || "").replace(/\s+/g, " ").trim()).filter(Boolean);
    row.replaceWith(doc.createTextNode(cells.join(" ") + "\n"));
  });
  content.querySelectorAll("h1,h2,h3,h4,h5,h6").forEach(heading => {
    const level = Number(heading.tagName.slice(1));
    heading.replaceWith(doc.createTextNode(`${"#".repeat(level)} ${heading.textContent.trim()}\n`));
  });
  content.querySelectorAll("br").forEach(node => node.replaceWith(doc.createTextNode("\n")));
  content.querySelectorAll("p,li,div").forEach(node => node.append(doc.createTextNode("\n")));
  return String(content.textContent || "").replace(/\u00a0/g, " ").replace(/[ \t]+/g, " ").replace(/\n[ \t]+/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
};
const parseWeaponHtml = (fetched, url) => {
  if (fetched.kind !== "html") return [];
  const slug = decodeURIComponent(new URL(url).pathname.split("/").pop() || "").toLowerCase();
  if (slug === "items:guns") return [];
  const doc = new DOMParser().parseFromString(String(fetched.text || ""), "text/html");
  const content = doc.querySelector("#page-content, .page-content, #pageContent") || doc.body;
  let rank = "";
  let previousName = "";
  const records = [];
  const readNumber = value => Number(String(value || "").replace(/,/g, "").match(/[+-]?\d+/)?.[0] || 0);
  for (const node of content.querySelectorAll("h1,h2,h3,h4,h5,h6,table")) {
    if (/^H[1-6]$/.test(node.tagName)) {
      const match = String(node.textContent || "").match(/\b(SS|S|A|B)\s*(?:-|–|—)?\s*Rank\b/i);
      if (match) { rank = match[1].toUpperCase(); previousName = ""; }
      continue;
    }
    const rows = [...node.querySelectorAll("tr")].map(row => [...row.querySelectorAll("th,td")].map(cell => String(cell.textContent || "").replace(/\\s+/g, " ").trim()));
    const headerIndex = rows.findIndex(row => row.some(cell => /^name$/i.test(cell)) && row.some(cell => /stance/i.test(cell)));
    if (headerIndex < 0) continue;
    const headers = rows[headerIndex].map(cell => cell.toLowerCase());
    const col = (pattern, fallback) => { const index = headers.findIndex(value => pattern.test(value)); return index >= 0 ? index : fallback; };
    const nameCol = col(/^name$/, 0), stanceCol = col(/stance/, 1), minCol = col(/min\s*str|strength/, 2);
    const accuracyCol = col(/acc\.?/, 3), powerCol = col(/^power$/, 4);
    const critCol = col(/^crit/, 15), damageCol = col(/add.?l?\s*dmg|additional\s*damage/, 16);
    const priceCol = col(/^price$/, 17), notesCol = col(/^notes?$/, 18);
    const tableCol = headers.map((value, index) => ({ value, index })).filter(entry => /^[③④⑤⑥⑦⑧⑨⑩⑪⑫]$/.test(entry.value));
    for (const cells of rows.slice(headerIndex + 1)) {
      const stance = cells[stanceCol] || "";
      if (!stance || !/^(?:1H|2H|特殊)/i.test(stance)) continue;
      const name = cells[nameCol] || previousName;
      if (name) previousName = name;
      if (!name) continue;
      const powerTable = {};
      if (tableCol.length) for (const entry of tableCol) powerTable[String("③④⑤⑥⑦⑧⑨⑩⑪⑫".indexOf(entry.value) + 3)] = readNumber(cells[entry.index]);
      else for (let i = 0; i < 10; i++) powerTable[String(i + 3)] = readNumber(cells[powerCol + 1 + i]);
      const critText = String(cells[critCol] || "");
      const critIndex = "③④⑤⑥⑦⑧⑨⑩⑪⑫".indexOf(critText);
      records.push({
        name, category:slug.replace(/^items:/, "").replace(/-/g, " "), rank, stance,
        usage:stance, minStrength:readNumber(cells[minCol]), accuracy:readNumber(cells[accuracyCol]),
        power:readNumber(cells[powerCol]), powerTable, critical:critIndex >= 0 ? critIndex + 3 : (readNumber(critText) || 10),
        additionalDamage:readNumber(cells[damageCol]), price:readNumber(cells[priceCol]),
        notes:cells[notesCol] || "", artificerPowered:false, maxMagazine:0, range:"", sourceUrl:url
      });
    }
  }
  return records;
};
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const canonical = value => {
  const u = new URL(I.normalizeUrl(value));
  // Wikidot codifica algunos enlaces a secciones como sufijos :1, :2, etc.
  // No son páginas distintas; pedirlas al proxy produce 404.
  try { u.pathname = decodeURIComponent(u.pathname).replace(/:\d+$/, ""); } catch (_) { u.pathname = u.pathname.replace(/%3A\d+$/i, ""); }
  u.hash = "";
  u.search = "";
  return u.href.replace(/\/$/, "");
};
const queue = START_URLS.map(canonical);
const visited = new Set();
const pages = [];
const errors = [];
const pageContexts = new Map();
ui.notifications.info(`SW25: comenzando recorrido de ${queue.length} índice(s).`);

while (queue.length && visited.size < MAX_PAGES) {
  const url = queue.shift();
  if (visited.has(url)) continue;
  visited.add(url);
  try {
    const fetched = await I.fetchPage(url);
    const text = String(fetched.text || "");
    const pageSlug = decodeURIComponent(new URL(url).pathname.replace(/^\//, "")).toLowerCase();
    const indexName = pageSlug.split(":", 1)[0];
    const contexts = sectionContexts(fetched, pageSlug);
    if (pageSlug === "feats") console.info("SW25 feat index section mappings", {
      mapped:contexts.size,
      passive:[...contexts].filter(([, value]) => value.category === "Selectively Acquired Passive").length,
      active:[...contexts].filter(([, value]) => value.category === "Selectively Acquired Active").length
    });
    // Extrae enlaces del HTML del proxy o de los enlaces Markdown de Reader.
    const found = new Set();
    for (const m of text.matchAll(/href\s*=\s*["']([^"']+)["']/gi)) found.add(m[1]);
    for (const m of text.matchAll(/\]\((https?:\/\/[^)]+|\/[^)]+)\)/g)) found.add(m[1]);
    for (const raw of found) {
      try {
        const link = canonical(new URL(raw, url).href);
        const slug = decodeURIComponent(new URL(link).pathname.replace(/^\//, ""));
        const childPath = decodeURIComponent(new URL(link).pathname.replace(/^\//, "")).toLowerCase();
        const childPrefix = childPath.split(":", 1)[0];
        const rootIndex = /^(races|classes|feats|spells|items|mounts)$/.test(childPath);
        let context = contexts.get(link) || pageContexts.get(url) || null;
        if (childPrefix === "spells" && childPath.includes(":")) context = { category:spellCategoryFromSlug(childPath) };
        if (childPrefix === "spell" && indexName === "spells") context = { category: pageSlug === "spells" ? "Other" : spellCategoryFromSlug(pageSlug) };
        if ((PAGE_PREFIXES.test(slug) || rootIndex) && !visited.has(link)) {
          if (context) pageContexts.set(link, context);
          queue.push(link);
        }
      } catch (_) { /* ignora enlaces ajenos a la wiki */ }
    }
    const slug = decodeURIComponent(new URL(url).pathname.replace(/^\//, ""));
    if (PAGE_PREFIXES.test(slug) || slug.toLowerCase() === "mounts") pages.push({ url, slug, fetched, context:pageContexts.get(url) || null });
  } catch (e) {
    errors.push(`${url}: ${e.message}`);
  }
  if (visited.size % 20 === 0) {
    ui.notifications.info(`Wiki SW25: revisadas ${visited.size}; páginas importables detectadas ${pages.length}.`);
    await sleep(DELAY_MS);
  }
}

const existingBySource = new Map();
for (const item of game.items.contents.filter(item => item.system?.sourceUrl)) {
  const source = canonical(item.system.sourceUrl);
  existingBySource.set(source, item);
  existingBySource.set(`${source}|${item.type}|${item.name.toLowerCase()}|${item.system.stance || item.system.usage || ""}`, item);
}
let created = 0, updated = 0, skipped = 0;
for (const page of pages) {
  try {
    const { url, slug, fetched } = page;
    const prefix = slug.split(":", 1)[0].toLowerCase();
    let data;
    let parsed;
    if (prefix === "race") {
      parsed = fetched.kind === "html" ? I.parseRaceHtml(fetched.text, url) : I.parseRaceMarkdown(fetched.text, url);
      data = { name:parsed.name, type:"race", system:{ sourceUrl:parsed.sourceUrl, description:parsed.description, languages:parsed.languages, restrictedClasses:parsed.restrictedClasses, lifespan:parsed.lifespan, soulscars:parsed.soulscars, corrections:parsed.corrections, backgrounds:parsed.backgrounds, rawText:parsed.rawText } };
    } else if (prefix === "class") {
      parsed = fetched.kind === "html" ? I.parseClassHtml(fetched.text, url) : I.parseClassMarkdown(fetched.text, url);
      data = { name:I.preferredClassName(parsed.name || "Imported Class"), type:"class", system:{ level:1, category:parsed.category || "A", sourceUrl:url, classType:parsed.classType || "", description:parsed.description || "", weaponRestrictions:parsed.weaponRestrictions || "", armourRestrictions:parsed.armourRestrictions || "", shieldRestrictions:parsed.shieldRestrictions || "", classFeatures:parsed.classFeatures || "", skillPackages:parsed.skillPackages || "", rawText:parsed.rawText || "" } };
    } else if (prefix === "feat") {
      parsed = fetched.kind === "html" ? I.parseFeatHtml(fetched.text, url) : I.parseFeatMarkdown(fetched.text, url);
      parsed.name = pageTitle(fetched, url);
      data = { name:parsed.name, type:"feat", system:{ category:"combat", prerequisite:parsed.prerequisite || "None", use:parsed.use || "", summary:parsed.summary || "", description:parsed.description || parsed.summary || "", sourceUrl:url, rawText:parsed.rawText || "", defenseModifier:Number(parsed.defenseModifier || 0) } };
    } else if (FEATURE_PREFIX.test(slug)) {
      const featureType = prefix === "essence-weaving" ? "weaving" : prefix;
      parsed = I.parseClassFeature(featureInput(fetched, url), url, { featureType });
      const className = featureType === "spell"
        ? (String(parsed.requirement || "").match(/^\s*([^,]+)/)?.[1]?.trim() || "")
        : featureClassName(featureType);
      data = { name:parsed.name, type:parsed.type, system:{ source:"class", classId:"", className, featureType:parsed.featureType, requirement:parsed.requirement, cost:parsed.cost, mpCost:parsed.mpCost, power:parsed.power, powerTable:parsed.powerTable, critical:parsed.critical, criticalModifier:parsed.criticalModifier, hasPowerTable:parsed.hasPowerTable, specialDamageBands:parsed.specialDamageBands || [], school:className, level:Number(String(parsed.requirement).match(/\d+/)?.[0] || 1), metadata:parsed.metadata, resourceData:parsed.resourceData, description:readablePowerTable(parsed), sourceUrl:url } };
    } else if (slug.toLowerCase() === "mounts") {
      const docs = parseMountRows(fetched, url).flatMap(item => I.equipmentDocuments(item));
      await upsertMany(docs, page);
      continue;
    } else if (prefix === "items") {
      if (WEAPON_CATEGORIES.has(slug.slice(6).toLowerCase())) {
        const weapons = parseWeaponHtml(fetched, url);
        if (!weapons.length) weapons.push(...I.parseWeaponTables(parserInput(fetched), url));
        if (!weapons.length) console.warn(`SW25: no se pudieron leer armas de ${url}`, { kind:fetched.kind, preview:parserInput(fetched).slice(0, 1200) });
        const primaryKeys = new Set();
        const docs = weapons.map(w => {
          const groupKey = `${w.rank || ""}|${w.name}`.toLowerCase();
          const wrestling = w.category?.toLowerCase() === "wrestling";
          const inventoryPrimary = wrestling ? false : !primaryKeys.has(groupKey);
          primaryKeys.add(groupKey);
          return { name:w.name, type:"weapon", system:{ equipped:wrestling, category:w.category || "", rank:w.rank || "", inventoryPrimary, stance:w.stance || "", usage:w.usage || w.stance || "", minStrength:Number(w.minStrength) || 0, accuracy:Number(w.accuracy) || 0, power:Number(w.power) || 0, critical:Number(w.critical) || 10, additionalDamage:Number(w.additionalDamage) || 0, maxMagazine:Number(w.maxMagazine) || 0, range:w.range || "", notes:w.notes || "", price:Number(w.price) || 0, selectedClassId:"", artificerPowered:Boolean(w.artificerPowered), powerTable:w.powerTable || {}, sourceUrl:url } };
        });
        await upsertMany(docs, page);
        continue;
      }
      if (["items:metal-armor", "items:nonmetallic-armor", "items:shields"].includes(slug.toLowerCase())) {
        let tables = I.parseArmourTables(parserInput(fetched)).filter(t => t.items?.length);
        if (slug.toLowerCase() !== "items:shields") {
          const fallback = I.armourFallbackTables(url);
          const byName = new Map(tables.map(t => [t.name.toLowerCase(), t]));
          for (const table of fallback) byName.set(table.name.toLowerCase(), table);
          tables = [...byName.values()];
        }
        const docs = tables.flatMap(table => table.items.map(a => ({ name:a.name, type:"armour", system:{ equipped:false, evasion:Number(a.evasion) || 0, defence:Number(a.defence) || 0, description:a.notes || "", magicalDefence:Number(a.magicalDefence) || 0, quantity:1, minStrength:Number(a.minStrength) || 0, notes:a.notes || "", sourceUrl:url } })));
        await upsertMany(docs, page);
        continue;
      }
      const options = EQUIPMENT_OPTIONS[slug.toLowerCase()];
      if (!options) { skipped++; continue; }
      const tables = options.classSpecific
        ? equipmentParser.parseClassSpecificItems(parserInput(fetched), url)
        : equipmentParser.parseEquipmentTables(parserInput(fetched), url, options);
      const docs = tables.flatMap(table => table.items.flatMap(item => I.equipmentDocuments(item)));
      if (!docs.length) console.warn(`SW25: no se pudo leer equipo de ${url}`, { kind:fetched.kind, preview:parserInput(fetched).slice(0, 1200) });
      await upsertMany(docs, page);
      continue;
    } else { skipped++; continue; }
    if (!data.name || !data.system.sourceUrl) { skipped++; continue; }
    if (data.type === "feat") console.info(`SW25 feat folder: ${data.name}`, { source:url, category:page.context?.category || "level-based", prerequisite:parsed?.prerequisite || data.system.prerequisite });
    data.folder = await folderFor(data, page, parsed);
    const old = existingBySource.get(canonical(data.system.sourceUrl));
    if (old) {
      await old.update({ name:data.name, type:data.type, system:data.system, folder:data.folder });
      updated++;
    } else {
      const [item] = await Item.createDocuments([data]);
      if (item) {
        const source = canonical(data.system.sourceUrl);
        existingBySource.set(source, item);
        existingBySource.set(`${source}|${data.type}|${data.name.toLowerCase()}|${data.system.stance || data.system.usage || ""}`, item);
      }
      created++;
    }
  } catch (e) {
    errors.push(`${page.url}: ${e.message}`);
  }
  await sleep(DELAY_MS);
}

async function upsertMany(docs, page) {
  for (const data of docs) {
    if (!data?.name || !data.system?.sourceUrl) { skipped++; continue; }
    data.folder = await folderFor(data, page);
    const key = canonical(data.system.sourceUrl);
    const identity = `${key}|${data.type}|${data.name.toLowerCase()}|${data.system.stance || data.system.usage || ""}`;
    const old = existingBySource.get(identity);
    if (old) {
      await old.update({ name:data.name, system:data.system, folder:data.folder });
      updated++;
    } else {
      const [item] = await Item.createDocuments([data]);
      if (item) existingBySource.set(identity, item);
      created++;
    }
  }
}

console.info("SW25 wiki import", { visited:visited.size, candidates:pages.length, created, updated, skipped, errors });
ui.notifications.info(`Importación SW25 terminada: ${created} nuevos, ${updated} actualizados, ${errors.length} errores. Revisa la consola para el detalle.`);
if (!pages.length) ui.notifications.warn(`No se detectaron páginas importables. Revisadas ${visited.size} URL(s); comprueba START_URLS y la consola.`);
if (errors.length) ui.notifications.warn(`Hubo ${errors.length} errores. Abre F12 > Console para ver las URL y detalles.`);
if (queue.length) ui.notifications.warn(`Se alcanzó MAX_PAGES=${MAX_PAGES}; quedan ${queue.length} enlaces pendientes. Añade índices más específicos o aumenta el límite.`);
} catch (error) {
  console.error("SW25 wiki import: error de ejecución", error);
  ui.notifications.error(`La macro SW25 se detuvo: ${error.message || error}. Abre F12 > Console para ver el detalle.`);
}
```

**Organización:** crea carpetas `Races/<Humanoid|Rare Humanoid|Barbarous>`, `Classes/<Warrior|Wizard|Other>`, `Feats/<Level N|Selectively Acquired Active|Selectively Acquired Passive>` y `Spells/<School>/<Level N>`. Las habilidades de Class Features se agrupan como `Features/<Class>/<Feature Type>` (por ejemplo, `Features/Bard/Finales`); la clase se asigna según la sección de la wiki. Las dos categorías Selectively Acquired de feats prevalecen sobre su nivel mínimo. Weapons se separan por tipo; armor por Metal Armor, Nonmetallic Armor y Shields. Equipment se subdivide según las categorías de la wiki (Accessories, Ammunition, Adventure Tools, etc.). Mounts van directamente en una carpeta Mounts, sin subcarpetas. Al reejecutarla, actualiza los items existentes y los mueve a la carpeta correspondiente.

**Alcance:** guarda razas, clases, feats, habilidades/conjuros, armas, armaduras/escudos, monturas y equipo como items del mundo. Importa todas las filas que el parser pueda leer en cada tabla; no abre los diálogos de selección del importador. El resultado depende de los enlaces que ofrezcan los índices iniciales y del acceso de red de Foundry al proxy usado por el sistema. Si Foundry sirve el sistema bajo una ruta distinta de `/systems/sword-world-25/`, ajusta la ruta del `import()` al principio de la macro.
