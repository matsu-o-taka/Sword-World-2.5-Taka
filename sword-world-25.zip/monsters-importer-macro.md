# Macro para importar monstruos

Esta es una macro independiente de la importación de items. Recorre el índice `/monsters`, pasa por los índices intermedios `monsters:` (categorías, nivel y hábitat), y crea actores de tipo **Monster** al encontrar páginas `monster:`. Los organiza en **Monstruos SW25 → categoría → Nivel N**. Si vuelves a ejecutarla, actualiza y recoloca el actor que tenga la misma URL de origen.

1. En Foundry, crea una macro de tipo **Script**.
2. Copia únicamente el código del bloque `js`.
3. Ejecútala como GM en una partida con Sword World 2.5 activo.

```js
ui.notifications.info("Macro de monstruos SW25 iniciada.");
console.info("SW25 monster import: started");
try {
  const I = game.sw25?.importer;
  if (!I) throw new Error("No se encuentra game.sw25.importer. Comprueba que Sword World 2.5 esté activo.");
  if (!game.user.isGM) throw new Error("Ejecuta esta macro como GM.");
  const { parseMonsterPage } = await import("/systems/sword-world-25/module/importer/monster-parser.mjs");

  const START_URLS = ["https://sw25.wikidot.com/monsters"];
  const MAX_PAGES = 1800;
  const DELAY_MS = 300;
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const canonical = value => {
    const u = new URL(I.normalizeUrl(value));
    u.hash = "";
    u.search = "";
    return u.href.replace(/\/$/, "");
  };
  const monsterInput = fetched => {
    if (fetched.kind !== "html") return fetched.text;
    const doc = new DOMParser().parseFromString(String(fetched.text || ""), "text/html");
    const title = String(doc.title || "").replace(/\s+-\s+Sword World.*$/i, "").trim();
    const content = doc.querySelector("#page-content, .page-content, #pageContent");
    if (!content) return fetched.text;
    content.querySelectorAll("script, style, noscript, .page-options-bottom, .page-info, .page-tags, .footer, #footer, #side-bar, #top-bar").forEach(node => node.remove());
    return `Title: ${title}\n\n${content.innerHTML}`;
  };

  let rootFolder = game.folders.find(f => f.type === "Actor" && f.name === "Monstruos SW25" && !f.folder);
  if (!rootFolder) rootFolder = await Folder.create({ name:"Monstruos SW25", type:"Actor" });
  const categoryNames = {
    animals:"Animals", barbarous:"Barbarous", constructs:"Constructs", daemons:"Daemons",
    fairies:"Fairies", golems:"Golems", humanoids:"Humanoids", magitech:"Magitech",
    "mythical-beasts":"Mythical Beasts", plants:"Plants", undead:"Undead"
  };
  const categoryFolders = new Map();
  const levelFolders = new Map();
  const getCategoryFolder = async category => {
    const name = categoryNames[category] || "Sin categoría";
    if (categoryFolders.has(name)) return categoryFolders.get(name);
    let folder = game.folders.find(f => f.type === "Actor" && f.name === name && f.folder?.id === rootFolder.id);
    if (!folder) folder = await Folder.create({ name, type:"Actor", folder:rootFolder.id });
    categoryFolders.set(name, folder.id);
    return folder.id;
  };
  const getLevelFolder = async (categoryFolderId, level) => {
    const numericLevel = Number(level);
    const name = Number.isFinite(numericLevel) && numericLevel > 0 ? `Nivel ${numericLevel}` : "Nivel desconocido";
    const key = `${categoryFolderId}|${name}`;
    if (levelFolders.has(key)) return levelFolders.get(key);
    let folder = game.folders.find(f => f.type === "Actor" && f.name === name && f.folder?.id === categoryFolderId);
    if (!folder) folder = await Folder.create({ name, type:"Actor", folder:categoryFolderId });
    levelFolders.set(key, folder.id);
    return folder.id;
  };

  const queue = START_URLS.map(url => ({ url:canonical(url), category:null }));
  const visited = new Set();
  const pagesByUrl = new Map();
  const monsterCategory = new Map();
  const errors = [];
  ui.notifications.info("SW25: recorriendo el índice de monstruos.");

  while (queue.length && visited.size < MAX_PAGES) {
    const entry = queue.shift();
    const { url, category } = entry;
    if (visited.has(url)) continue;
    visited.add(url);
    try {
      const fetched = await I.fetchPage(url);
      const text = String(fetched.text || "");
      const links = new Set();
      for (const m of text.matchAll(/href\s*=\s*["']([^"']+)["']/gi)) links.add(m[1]);
      for (const m of text.matchAll(/\]\((https?:\/\/[^)]+|\/[^)]+)\)/g)) links.add(m[1]);
      for (const raw of links) {
        try {
          const link = canonical(new URL(raw, url).href);
          const slug = decodeURIComponent(new URL(link).pathname.replace(/^\//, ""));
          if (/^monster:/i.test(slug)) {
            if (category && categoryNames[category]) monsterCategory.set(link, category);
            if (!visited.has(link)) queue.push({ url:link, category:categoryNames[category] ? category : null });
          } else if (/^monsters:/i.test(slug) && !visited.has(link)) {
            const key = slug.split(":").slice(1).join(":").toLowerCase();
            queue.push({ url:link, category:categoryNames[key] ? key : null });
          }
        } catch (_) { /* ignora enlaces externos o mal formados */ }
      }
      const slug = decodeURIComponent(new URL(url).pathname.replace(/^\//, ""));
      if (/^monster:/i.test(slug)) {
        if (category && categoryNames[category]) monsterCategory.set(url, category);
        pagesByUrl.set(url, { url, fetched });
      }
    } catch (e) {
      errors.push(`${url}: ${e.message}`);
    }
    if (visited.size % 20 === 0) {
      ui.notifications.info(`Monstruos SW25: revisadas ${visited.size}; monstruos detectados ${pagesByUrl.size}.`);
      await sleep(DELAY_MS);
    }
  }

  const existing = new Map(game.actors.contents
    .filter(actor => actor.type === "monster" && actor.system?.sourceUrl)
    .map(actor => [canonical(actor.system.sourceUrl), actor]));
  let created = 0, updated = 0, skipped = 0;
  for (const page of pagesByUrl.values()) {
    try {
      const parsed = parseMonsterPage(monsterInput(page.fetched), page.url);
      if (!parsed.name || !parsed.system?.sourceUrl) { skipped++; continue; }
      const categoryFolder = await getCategoryFolder(monsterCategory.get(page.url));
      const targetFolder = await getLevelFolder(categoryFolder, parsed.system.level);
      const old = existing.get(canonical(parsed.system.sourceUrl));
      if (old) {
        await old.update({ name:parsed.name, system:parsed.system, folder:targetFolder });
        updated++;
      } else {
        const [actor] = await Actor.createDocuments([{ name:parsed.name, type:"monster", system:parsed.system, folder:targetFolder }]);
        if (actor) existing.set(canonical(parsed.system.sourceUrl), actor);
        created++;
      }
    } catch (e) {
      errors.push(`${page.url}: ${e.message}`);
    }
    await sleep(DELAY_MS);
  }

  console.info("SW25 monster import", { visited:visited.size, candidates:pagesByUrl.size, created, updated, skipped, errors });
  ui.notifications.info(`Monstruos SW25: ${created} nuevos, ${updated} actualizados, ${errors.length} errores.`);
  if (!pagesByUrl.size) ui.notifications.warn("No se detectaron páginas monster:. Comprueba que el índice siga enlazando las páginas de monstruos.");
  if (errors.length) ui.notifications.warn("Hubo errores. Abre F12 > Console para ver las URL y el detalle.");
  if (queue.length) ui.notifications.warn(`Se alcanzó MAX_PAGES=${MAX_PAGES}; quedan ${queue.length} enlaces pendientes.`);
} catch (error) {
  console.error("SW25 monster import: execution error", error);
  ui.notifications.error(`La macro de monstruos se detuvo: ${error.message || error}. Abre F12 > Console para el detalle.`);
}
```

La macro importa los campos que lee el parser de monstruos del sistema: estadísticas, estilos de combate, habilidades especiales y botín. Los actores se crean sin revelar (`revealed: false`), igual que cuando se importa un monstruo mediante la ficha del sistema. Si la wiki no proporciona un nivel legible para una página, el actor se guarda en **Nivel desconocido** dentro de su categoría.
